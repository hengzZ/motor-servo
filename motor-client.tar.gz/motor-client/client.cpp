#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <regex>

using namespace std;

#define SERVER_PORT 12345   // arbitrary, but client & server must agree
#define BUF_SIZE    4096    // block transfer size


int main(int argc, char** argv)
{
        int c, s, bytes;
        char buf[BUF_SIZE];             // buffer for incoming information
        struct sockaddr_in channel;     // holds IP address

        string cmdStr;
        std::regex cancel_task_regex("^cancel$");                                               // cancel
        std::regex stop_regex("^stop$");                                                        // stop
        std::regex run_to_point_regex("^point (-?[0-9]+.?[0-9]*)$");                            // point (-)0000000
        std::regex left_run_regex("^runleft$");                                                 // runleft
        std::regex right_run_regex("^runright$");                                               // runright
        std::regex speed_regex("^speed ([0-9]+)$");                                             // speed 000000
        std::regex acce_regex("^acce ([0-9]+)$");                                               // acce 000000
        std::regex dece_regex("^dece ([0-9]+)$");                                               // dece 000000
        std::regex max_point_regex("^maxpoint (-?[0-9]+.?[0-9]*) (-?[0-9]+.?[0-9]*)$");         // maxpoint (-)000000 (-)000000
        std::regex get_status_regex("^status (0|1)$");                                          // status 0 (or 1)
        std::regex help_regex("^help$");                                                        // help
        std::smatch base_match;

        // Build address structure
        memset(&channel, 0, sizeof(channel));
        channel.sin_family = AF_INET;
        channel.sin_addr.s_addr = inet_addr("192.168.0.15");
        channel.sin_port = htons(SERVER_PORT);

        s = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);                      // create socket
        if(s < 0) {
                    perror("socket failed.");
                    return -1;
        }
        c = connect(s, (struct sockaddr *)&channel, sizeof(channel));
        if(c < 0) {
                    perror("connect failed.");
                    return -1;
        }
        perror("socket connect");

        bool loop = true;
        while(loop) {
                cout << "motor-client$ ";
                std::getline(std::cin, cmdStr);
                if(std::regex_match(cmdStr, base_match, cancel_task_regex)){
                        cout << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, stop_regex)){
                        cout << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, run_to_point_regex)){
                        cout << stod(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, left_run_regex)){
                        cout << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, right_run_regex)){
                        cout << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, speed_regex)){
                        cout << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, acce_regex)){
                        cout << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, dece_regex)){
                        cout << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, max_point_regex)){
                        cout << stod(base_match[1].str()) << endl;
                        cout << stod(base_match[2].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, get_status_regex)){
                        cout << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, help_regex)){
                        cout << "Usage:" << endl;
                        cout << "       cancel                      \n"
                                "       stop                        \n"
                                "       point (-)0000000            \n"
                                "       runleft                     \n"
                                "       runright                    \n"
                                "       speed 000000                \n"
                                "       acce 000000                 \n"
                                "       dece 000000                 \n"
                                "       maxpoint (-)000000 (-)000000\n"
                                "       status 0 (or 1)             \n"
                                "       help                        " << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = write(s, ptr, strlen(ptr)+1);
                }else {   
                        bytes = write(s,"help",strlen("help")+1);
                }         
                if(0 == bytes) {
                        cerr << "write bytes to socket failed." << endl;
                }
                auto start = std::chrono::high_resolution_clock::now();
                std::this_thread::sleep_for(std::chrono::duration<int,std::milli>(10));
                auto end = std::chrono::high_resolution_clock::now();
                std::chrono::duration<double,std::milli> elapsed = end -start;
                std::cout << "Waited" << elapsed.count() << " ms" << endl;
        }                 

        return 0;
}

