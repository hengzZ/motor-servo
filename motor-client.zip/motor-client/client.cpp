#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <mutex>
#include <regex>

using namespace std;

#define SERVER_PORT 12345   // arbitrary, but client & server must agree


// TCP
//int c, s, bytes;
//struct sockaddr_in channel;
// UDP
int sock, bytes=0;
struct sockaddr_in addr; 

std::mutex s_mutex;


int my_read_socket(char* str, const int size)
{
        std::lock_guard<std::mutex> guard(s_mutex);

        // TCP
        //return read(s, str, size);
        // UDP
        int len = sizeof(addr);
        return recvfrom(sock, str, size, 0, (struct sockaddr*)&addr, (socklen_t*)&len);
}
int my_write_socket(const char* str, const int size)
{
        std::lock_guard<std::mutex> guard(s_mutex);

        // TCP
        //return write(s, str, size);
        // UDP
        return sendto(sock, str, size, 0, (struct sockaddr *)&addr, sizeof(addr));
}
// 接收数据监听
void RecvSocketDatas(void);


int main(int argc, char** argv)
{

        string cmdStr;
        std::regex cancel_task_regex("^cancel$");                                               // cancel
        std::regex stop_regex("^stop$");                                                        // stop
        std::regex run_to_point_regex("^point (-?[0-9]+.?[0-9]*)$");                            // point (-)000.000 (unit: degree)
        std::regex left_run_regex("^runleft$");                                                 // runleft
        std::regex right_run_regex("^runright$");                                               // runright
        std::regex speed_regex("^speed ([0-9]+.?[0-9]*)$");                                     // speed 000.000 (unit: degree/s)
        std::regex acce_regex("^acce ([0-9]+)$");                                               // acce 000000 (0.1ms)
        std::regex dece_regex("^dece ([0-9]+)$");                                               // dece 000000 (0.1ms)
        std::regex max_point_regex("^maxpoint (-?[0-9]+.?[0-9]*) (-?[0-9]+.?[0-9]*)$");         // maxpoint (-)000.000 (-)000.000
        std::regex get_status_regex("^status (0|1)$");                                          // status 0 (or 1)
        std::regex help_regex("^help$");                                                        // help
        std::regex check_regex("^check$");                                                      // check
        std::smatch base_match;

        // // TCP
        // memset(&channel, 0, sizeof(channel));
        // channel.sin_family = AF_INET;
        // channel.sin_addr.s_addr = inet_addr("192.168.0.15");
        // channel.sin_port = htons(SERVER_PORT);
        // s = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);                      // create socket
        // if(s < 0) {
        //             perror("socket failed.");
        //             return -1;
        // }
        // c = connect(s, (struct sockaddr *)&channel, sizeof(channel));
        // if(c < 0) {
        //             perror("connect failed.");
        //             return -1;
        // }

        // UDP
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = inet_addr("192.168.1.15");
		addr.sin_port = htons(SERVER_PORT);
		sock = socket(AF_INET, SOCK_DGRAM, 0);
        if(sock < 0){
                perror("socket failed.");
                return -1;
        }
       
		perror("socket connect");
        
        // // Create thread for socket receving
        // std::thread t1(RecvSocketDatas);
        // t1.detach();

        bool loop = true;
        while(loop) {
                cerr << "<motor-client>$ ";

                std::getline(std::cin, cmdStr);
                if(std::regex_match(cmdStr, base_match, cancel_task_regex)){
                        cerr << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, stop_regex)){
                        cerr << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, run_to_point_regex)){
                        cerr << stod(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, left_run_regex)){
                        cerr << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, right_run_regex)){
                        cerr << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, speed_regex)){
                        cerr << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, acce_regex)){
                        cerr << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, dece_regex)){
                        cerr << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, max_point_regex)){
                        cerr << stod(base_match[1].str()) << endl;
                        cerr << stod(base_match[2].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, get_status_regex)){
                        cerr << stoi(base_match[1].str()) << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, check_regex)){
                        cerr << base_match[0].str() << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else if(std::regex_match(cmdStr, base_match, help_regex)){
                        cerr << "Usage:" << endl;
                        cerr << "       cancel                      \n"
                                "       stop                        \n"
                                "       point (-)0000000            \n"
                                "       runleft                     \n"
                                "       runright                    \n"
                                "       speed 000000                \n"
                                "       acce 000000                 \n"
                                "       dece 000000                 \n"
                                "       maxpoint (-)000000 (-)000000\n"
                                "       status 0 (or 1)             \n"
                                "       help                        " << endl;
                        const char *ptr = base_match[0].str().c_str();
                        bytes = my_write_socket(ptr, strlen(ptr)+1);
                }else {   
                        bytes = my_write_socket("help",strlen("help")+1);
                }         
                if(0 == bytes) {
                        cerr << "write bytes to socket failed." << endl;
                }

                char buf[1024];
                memset(buf,0,1024);
                int ret = my_read_socket(buf,1023);
                printf("read %d chars\n",ret);
                printf("%s\n",buf);

                //auto start = std::chrono::high_resolution_clock::now();
                //std::this_thread::sleep_for(std::chrono::duration<int,std::milli>(10));
                //auto end = std::chrono::high_resolution_clock::now();
                //std::chrono::duration<double,std::milli> elapsed = end -start;
                //std::cerr << "Waited" << elapsed.count() << " ms" << endl;
        }                 

        return 0;
}

void RecvSocketDatas(void)
{
        while(1)
        {
                char buf[1024];
                memset(buf,0,1024);
                int ret = my_read_socket(buf,1023);
                printf("read %d chars\n",ret);
                printf("%s\n",buf);
                std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
}
